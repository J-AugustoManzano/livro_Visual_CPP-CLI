// C10EX07.cpp

#include "C10EX07.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela()); 
  return 0;
}
