// C01EX01.cpp

#include <iostream>
using namespace std;

int main()
{
  cout << "Estudo de Visual C++." << endl;
  return 0;
}
