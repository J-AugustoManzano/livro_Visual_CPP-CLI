// C10EX11.cpp

#include "C10EX11.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}
