// C10EX10.cpp

#include "C10EX10.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}
