// C07EX11.cpp

#include "stdafx.h"
using namespace System;

int main(void)
{
  register Int32 I;
  for(I = 1; I <= 20; I++)
    Console::WriteLine(I);
  return 0;
}
