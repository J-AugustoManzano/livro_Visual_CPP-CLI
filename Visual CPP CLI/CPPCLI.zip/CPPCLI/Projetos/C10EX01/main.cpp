#include "C10EX01.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}
