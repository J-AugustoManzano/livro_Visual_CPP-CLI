// C01EX02.cpp

#include <stdio.h>

int main()
{
  printf("Estudo de Visual C.\n");
  return 0;
}
