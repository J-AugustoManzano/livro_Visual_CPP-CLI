// C10EX17.cpp

#include "C10EX17_Pai.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew TelaPai());
  return 0;
}
