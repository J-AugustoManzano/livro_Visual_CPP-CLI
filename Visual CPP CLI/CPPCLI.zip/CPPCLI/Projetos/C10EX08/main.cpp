// C10EX08.cpp

#include "C10EX08.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}
