// C10EX06.cpp

#include "C10EX06.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}

