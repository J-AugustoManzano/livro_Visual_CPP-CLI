// C10EX14.cpp

#include "C10EX14.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}

