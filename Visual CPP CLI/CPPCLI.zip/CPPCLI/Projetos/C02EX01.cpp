// C02EX01.cpp

#include "stdafx.h"
using namespace System;

int main()
{
  Console::WriteLine("Alo, mundo!");
  return 0;
}
