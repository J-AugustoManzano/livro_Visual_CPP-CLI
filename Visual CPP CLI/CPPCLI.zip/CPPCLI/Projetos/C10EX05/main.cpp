// C10EX05.cpp

#include "C10EX05.h"
using namespace MeuFormulario;

int main()
{
  Application::Run(gcnew Tela());
  return 0;
}
